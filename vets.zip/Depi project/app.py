from flask import Flask, request, jsonify
from flask_cors import CORS
import pyodbc

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests for frontend

# Database connection
conn = pyodbc.connect(
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=localhost;"
    "Database=vets_db;"
    "Trusted_Connection=yes;"
)
cursor = conn.cursor()

# Get vets by city
@app.route("/vets", methods=["GET"])
def get_vets():
    city = request.args.get("city", "")
    if not city:
        return jsonify({"error": "City parameter is required"}), 400
    try:
        query = """
        SELECT name, specialty, address, phone
        FROM dbo.vets
        WHERE address LIKE ?
        """
        cursor.execute(query, (f"%{city}%",))
        rows = cursor.fetchall()
        vets_list = []
        for r in rows:
            vets_list.append({
                "name": r[0],
                "specialty": r[1],
                "address": r[2],
                "phone": r[3] or "Not available"
            })
        return jsonify(vets_list)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)