import requests
import pyodbc

city_input = input("Enter the city name: ").strip()

url = "https://nominatim.openstreetmap.org/search"
params = {
    "q": f"veterinary clinic in {city_input}",
    "format": "json",
    "limit": 100
}

response = requests.get(url, params=params, headers={'User-Agent': 'Mozilla/5.0'}).json()

data = []
for r in response:
    name = r.get("display_name").split(",")[0]
    address = r.get("display_name")
    specialty = "Veterinary"
    phone = None
    photo_reference = None
    data.append((name, specialty, address, phone, photo_reference))

print(f"Number of results fetched: {len(data)}")

if data:
    conn = pyodbc.connect(
        "Driver={ODBC Driver 17 for SQL Server};"
        "Server=localhost;"
        "Database=vets_db;"
        "Trusted_Connection=yes;"
    )

    cursor = conn.cursor()

    insert_query = """
    INSERT INTO dbo.vets (name, specialty, address, phone, photo_reference)
    VALUES (?, ?, ?, ?, ?)
    """
    cursor.executemany(insert_query, data)
    conn.commit()
    print(f"{len(data)} records have been inserted into the database.")
else:
    print("No data to insert. Please check the city name.")

if data:
    def search_vets_by_city(city_name):
        query = """
        SELECT name, address, phone
        FROM dbo.vets
        WHERE address LIKE ?
        """
        cursor.execute(query, (f"%{city_name}%",))
        return cursor.fetchall()

    while True:
        city_search = input("Enter the city name to search (or type 'exit' to quit): ").strip()
        if city_search.lower() == "exit":
            break
        results = search_vets_by_city(city_search)
        if not results:
            print("No clinics found in this city.")
        else:
            print(f"Clinics in {city_search}:")
            for r in results:
                print(f"- {r[0]} | {r[1]} | {r[2] or 'Phone not available'}")

    cursor.close()
    conn.close()
    print("Database connection closed.")