IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'vets_db')
BEGIN
    CREATE DATABASE vets_db;
END
GO

USE vets_db;
GO

IF OBJECT_ID('dbo.vets', 'U') IS NOT NULL
BEGIN
    DROP TABLE dbo.vets;
END
GO

CREATE TABLE dbo.vets (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    address VARCHAR(300) NOT NULL,
    phone VARCHAR(30) NULL,
    photo_reference VARCHAR(255) NULL
);
GO

SELECT * FROM dbo.vets;
GO
