# %%
from deep_translator import GoogleTranslator
from pypdf import PdfReader
from pptx import Presentation
import json
from nbformat import read
from langchain.text_splitter import RecursiveCharacterTextSplitter
from transformers import BartForConditionalGeneration, BartTokenizer, pipeline
from langchain.llms import HuggingFacePipeline
from langchain import PromptTemplate
import os
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain_openai import ChatOpenAI
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document


# %%
def read_pdf(file_path):
    reader = PdfReader(file_path)
    text=''
    for page_num in range(len(reader.pages)):
            text += reader.pages[page_num].extract_text()
    return text

def read_powerpoint(file_path):
    presentation = Presentation(file_path)
    slides_text = []
    for slide in presentation.slides:
        slide_text = []
        for shape in slide.shapes:
            try:
                # Extract text from text frames
                if shape.has_text_frame:
                    text_frame = shape.text_frame
                    for paragraph in text_frame.paragraphs:
                        for run in paragraph.runs:
                            slide_text.append(run.text)
            except AttributeError:
                pass  
        
        # Join all text from the slide into a single string
        slides_text.append(' '.join(slide_text))
    return str(slides_text)

def read_notebook(notebook_path):
    with open(notebook_path, 'r', encoding='utf-8') as f:
        notebook = json.load(f)
    code_cells = []
    for cell in notebook['cells']:
        if cell['cell_type'] == 'code':
            # Extract the source code from the cell
            code = ''.join(cell['source'])
            code_cells.append(code)
    all_code = '\n'.join(code_cells)
    return str(all_code)

def read_py(py_file_path):
    with open(py_file_path, 'r', encoding='utf-8') as py_file:
        content = py_file.read()
    return str(content)

def return_content(file_path):
    file_name, file_extension = os.path.splitext(file_path)
    file_extension = file_extension.lower()
    text=''
    if file_extension == '.pdf':
        text=read_pdf(file_path)
    elif file_extension == '.pptx':
        text=read_powerpoint(file_path)
    elif file_extension == '.ipynb':
        text=read_notebook(file_path)
    elif file_extension == '.py':
        text=read_py(file_path)
    return text

# %%

def split_text(text):
    text_splitter = RecursiveCharacterTextSplitter(
     chunk_size=1000,
     chunk_overlap=100,
    length_function=len,
    )
    docs = text_splitter.create_documents([text])
    return docs

# %%
def custom_prompt_forall():
    return  """Use the following information to answer the question in a simple, clear way.
    Rules:
    If the question is in Arabic, answer in Arabic.
    If the question is in English, answer in English.
    Prioritize the provided {context}. If the information is not in the context, you may use your own knowledge.
    Keep the answer short, clear, and easy to understand.
    Do not include reasoning steps or extra sections—only the final answer.
    {context}
    question: {question}
    answer:
    """


# %%
def run_model(qa_chain):
    print("You can ask now , if you want finish enter Exit \n")
    while True:
        user_query = input(" How can i help you?\n")
        if user_query.lower() == 'exit':
            print("Bye_Bye")
            break
        try:
            response = qa_chain.invoke({"query": user_query})
            print(f" {response['result']}")
        except Exception as e:
            print("الرجاء التأكد من اتصالك بالإنترنت وصحة مفتاح API الخاص بك.")

# %%
def total_summary(qa_chain):
    user_query = (" write a concise summary of the file in simple clear language")
    response = qa_chain.invoke({"query": user_query})
    return response['result']

def Key_points(qa_chain):
    user_query = (" list the key points from the file as bullet points")
    response = qa_chain.invoke({"query": user_query})
    return response['result']

# %%
def model_open_Ai(embeddings,db):
    os.environ["OPENAI_API_KEY"] = "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"
    llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0)
    custom_prompt_template =  custom_prompt_forall()
    custom_prompt = PromptTemplate(template=custom_prompt_template, input_variables=["context", "question"])
    qa_chain = RetrievalQA.from_chain_type(
       llm=llm,
       chain_type="stuff",
       retriever=db.as_retriever(),
       chain_type_kwargs={"prompt": custom_prompt}
    )
    return qa_chain



def model_open_router(embeddings,db):
    os.environ["OPENROUTER_API_KEY"] = "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"
    llm = llm = ChatOpenAI(
       model_name="mistralai/mistral-7b-instruct",
       base_url="https://openrouter.ai/api/v1",
       openai_api_key=os.environ.get("OPENROUTER_API_KEY"),
       temperature=0
    )
    custom_prompt_template = custom_prompt_forall()
    custom_prompt = PromptTemplate(template=custom_prompt_template, input_variables=["context", "question"])
    qa_chain = RetrievalQA.from_chain_type(
       llm=llm,
       chain_type="stuff", # "stuff" تجمع كل السياق في طلب واحد
       retriever=db.as_retriever(),
       chain_type_kwargs={"prompt": custom_prompt}
    )
    return qa_chain

def model_google_base(embeddings,db):
    llm_model_name = "google/flan-t5-base"
    llm_model = pipeline(
       "text2text-generation",
        model=llm_model_name,
        framework="pt",
        max_length=300
    )
    llm = HuggingFacePipeline(pipeline=llm_model)
    custom_prompt_template = custom_prompt_forall()
    custom_prompt = PromptTemplate(template=custom_prompt_template, input_variables=["context", "question"])
    qa_chain = RetrievalQA.from_chain_type(
      llm=llm,
      chain_type="stuff",
      retriever=db.as_retriever(),
      chain_type_kwargs={"prompt": custom_prompt}
      )
    return qa_chain


# %%
def Chat_Bot():
    file_path= r"./data/VETERINARY TOXICOLOGY AND PHARMACY.pdf"
    text=return_content(file_path)
    docs= split_text(text)
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = FAISS.from_documents(docs, embeddings)
    # model chatgpt
    try: 
        run_model(model_open_Ai(embeddings,db))
    except:
        pass
      # model open_router(prefect)
    try:
        run_model(model_open_router(embeddings,db))
    except:
        pass
    # model google_base
    try:
        run_model(model_google_base(embeddings,db))
    except:
        pass

# %%
def summary():
    file_path=r"./data/VETERINARY TOXICOLOGY AND PHARMACY.pdf"
    text=return_content(file_path)
    docs= split_text(text)
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = FAISS.from_documents(docs, embeddings)
    # model chatgpt and open router
    try: 
        print("Th total summary is:\n")
        print(total_summary(model_open_Ai(embeddings,db)))
        print("\n\n the key points is \n")
        print(Key_points(model_open_router(embeddings,db)))
    except:
        pass




